import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function Setting() {
  const navigate = useNavigate();

  // State Hooks for Controlled Inputs
  const [interval, setInterval] = useState("");
  const [email, setEmail] = useState("");
  const [autoMeasure, setAutoMeasure] = useState(false);

  const handleSave = () => {
    console.log("Settings saved:", { interval, email, autoMeasure });
    // You may add API calls here to save data
  };

  return (
    <div className="container mt-3">
      {/* General Settings Section */}
      <div className="row">
        <div className="col-lg-12">
          <div
            style={{
              backgroundColor: "black",
              color: "white",
              padding: "5px",
              marginTop: "10px",
              borderRadius: "10px",
            }}
          >
            <h3>General Settings</h3>
          </div>

          <div className="form-group mt-3">
            <label>
              <b>Sampling interval:</b>
            </label>
            <input
              type="number"
              min="0"
              className="form-control input-field"
              value={interval}
              onChange={(e) => setInterval(e.target.value)}
            />
            <span>Seconds</span>
          </div>

          <div className="form-group mt-2">
            <label>
              <b>Email Address:</b>
            </label>
            <input
              type="email"
              className="form-control input-field"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <span>For sending backup data (monthly)</span>
          </div>

          <div className="form-group">
            <label>
              <b>Auto Measure:</b>
            </label>
            <div className="form-check form-switch">
              <input
                type="checkbox"
                className="form-check-input toggle-switch"
                checked={autoMeasure}
                onChange={() => setAutoMeasure(!autoMeasure)}
              />
            </div>
          </div>

          <div className="d-flex justify-content-end">
            <button className="btn btn-primary btn-lg" onClick={handleSave}>
              <b>Save</b>
            </button>
          </div>
        </div>
      </div>

      {/* Sensor Settings Section */}
      <div className="row mt-4">
        <div className="col-lg-12">
          <div
            style={{
              backgroundColor: "black",
              color: "white",
              padding: "5px",
              marginTop: "10px",
              borderRadius: "10px",
            }}
          >
            <h3>Sensor Settings</h3>
          </div>

          <div className="d-flex justify-content-end">
            <button
              className="btn btn-success mt-2  mx-2"
              onClick={() => navigate("/addrainsensor")}
            >
              <i className="fa fa-plus"></i> Add Rain Sensor
            </button>
            <button
              className="btn btn-success mt-2 "
              onClick={() => navigate("/addsensor")}
            >
              <i className="fa fa-plus"></i> Add Sensor
            </button>
          </div>

          <div style={{ maxHeight: "220px", overflowY: "auto" }}>
            <div className="table-responsive mt-3">
              <table className="table table-bordered">
                <thead>
                  <tr>
                    <th>SENSOR NAME</th>
                    <th>PARAMETER NAME</th>
                    <th>ACTIONS</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { name: "AT500", parameters: "pH, TSS, NH3N" },
                    { name: "AT500", parameters: "pH, TSS, NH3N" },
                    { name: "AT500", parameters: "pH, TSS, NH3N" },
                    { name: "Mace", parameters: "Debit" },
                    { name: "Spectro::lyser", parameters: "COD, BOD" },
                  ].map((sensor, index) => (
                    <tr key={index}>
                      <td>{sensor.name}</td>
                      <td>{sensor.parameters}</td>
                      <td>
                        <button className="btn btn-warning btn-sm mx-2">
                          <i className="fa fa-edit"></i>
                        </button>
                        <button className="btn btn-danger btn-sm">
                          <i className="fa fa-trash"></i>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Setting;
