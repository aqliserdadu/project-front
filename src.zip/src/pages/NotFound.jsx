function NotFound(){

    return(
        <>
            <h1>tidak ada</h1>
        </>
    )
}

export default NotFound