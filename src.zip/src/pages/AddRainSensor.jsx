import React from "react";
import { useNavigate } from "react-router-dom";


function AddRainSensor() {
    const navigate = useNavigate();
    return (<>
        <div className="container mt3">
            <div className="row">
                <div className="col-md-12 col-lg-12">
                    <div style={{ backgroundColor: "black", color: "white", padding: "5px", marginTop: "10px", borderRadius: "10px" }}>
                        <h3>Rain sensor digital settings</h3>

                    </div>
                    <div style={{ marginTop: "20px" }}>
                        <label style={{ fontSize: "20px" }}><b>Sensor name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :</b></label> &nbsp;  <input type="text" id="sensor" name="sensor" style={{ width: "200px", borderRadius: "10px" }} />
                    </div>
                    <div style={{ marginTop: "20px" }}>
                        <label style={{ fontSize: "20px" }}><b>Tipping volume &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :</b></label> &nbsp;<input type="text" id="tipping" name="tipping" style={{ width: "200px", borderRadius: "10px" }} /> &nbsp;&nbsp;&nbsp; <span>ml</span>
                    </div>

                    <div className="d-flex justify-content-between mt-5">
                        <button className="btn btn-secondary" onClick={() => navigate(-1)}>
                            <i className="fa fa-arrow-left"></i> Back
                        </button>
                        <button className="btn btn-success">
                            <i className="fa fa-save"></i> Save
                        </button>
                    </div>
                </div>
            </div>
        </div>


    </>)
}


export default AddRainSensor