function EthSet(){

    return(
        <>
            <h1>ini EthSet</h1>
        </>
    )
}

export default EthSet