function Service() {

    return (
        <>
            <div className="row">
                    <div className="col-lg-12 col-md-12 ms-sm-auto">
                        asd
                    </div>
                </div>
        </>
    )

}

export default Service