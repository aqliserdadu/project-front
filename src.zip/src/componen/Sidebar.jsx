function Sidebar() {

    return (
        <>
            <nav className="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                <div className="d-flex flex-column">
                    <div style={{height:"128px", backgroundColor:"blue"}}>as</div>    
                    <div style={{height:"128px", backgroundColor:"black"}}>as</div>    
                    <div style={{height:"128px", backgroundColor:"blue"}}>as</div>    
                    <div style={{height:"128px", backgroundColor:"yellow"}}>as</div>    
                    <div style={{height:"128px", backgroundColor:"blue"}}>as</div>    
                    <div style={{height:"128px", backgroundColor:"black"}}>as</div>    
                </div>
            </nav>
        </>
    )

}

export default Sidebar